// Main.java
/*
 * EE422C Quiz 1 submission by
 * Alan Penichet-Paul
 * Ap46378
 * 16190
 * Spring 2019
 */

public class Main {
	/**
	 * Prints "Hello World" by calling HelloWorld.hello().
	 * 
	 * @param args a string of arguments passed in.
	 */
	public static void main(String[] args) {
		//HelloWorld.hello();
		HelloWorld.printmsg("Hello, world!");
	}
}
